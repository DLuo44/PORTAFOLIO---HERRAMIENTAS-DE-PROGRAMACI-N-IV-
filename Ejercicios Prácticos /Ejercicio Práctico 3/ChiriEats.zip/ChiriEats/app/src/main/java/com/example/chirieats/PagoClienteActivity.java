package com.example.chirieats;

import android.content.Intent;
import android.net.Uri;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * PagoClienteActivity — Simulación de Pago con Yappy Comercial.
 *
 * Permite al usuario:
 * 1. Adjuntar una captura de pantalla del recibo de pago Yappy
 * 2. Ingresar el monto pagado
 * 3. Confirmar el pago, generando un JSON en Logcat
 * 4. Ejecutar la simulación de cálculos de ITBMS.
 * 5. ENLACE DE RED: Envía en tiempo real el pedido a MariaDB (Linux Mint) para activar la réplica.
 */
public class PagoClienteActivity extends AppCompatActivity {

    private static final String TAG = "PAGO_JSON";
    private static final String TAG_SIM = "SIMULACION";

    private ImageButton btnBack;
    private ImageView ivCaptura;
    private TextView tvImageLabel;
    private MaterialButton btnAdjuntar;
    private TextInputEditText etMonto;
    private MaterialButton btnConfirmarPago;

    private double totalPago;
    private DatabaseHelper dbHelper;

    /** URI de la imagen seleccionada de la galería */
    private Uri imagenSeleccionadaUri = null;

    /**
     * Launcher para seleccionar una imagen de la galería.
     * Usa el contrato GetContent con tipo "image/*".
     */
    private final ActivityResultLauncher<String> imagePickerLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.GetContent(),
                    new ActivityResultCallback<Uri>() {
                        @Override
                        public void onActivityResult(Uri uri) {
                            if (uri != null) {
                                imagenSeleccionadaUri = uri;
                                mostrarImagenSeleccionada(uri);
                            }
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pago_cliente);

        dbHelper = new DatabaseHelper(this);
        totalPago = getIntent().getDoubleExtra("total_pago", 0.0);

        initViews();
        setupListeners();

        // Sugerir el monto total a pagar
        if (totalPago > 0) {
            etMonto.setText(String.format("%.2f", totalPago).replace(",", "."));
        }
    }

    /**
     * Enlaza las vistas del layout.
     */
    private void initViews() {
        btnBack         = findViewById(R.id.btnBack);
        ivCaptura       = findViewById(R.id.ivCaptura);
        tvImageLabel    = findViewById(R.id.tvImageLabel);
        btnAdjuntar     = findViewById(R.id.btnAdjuntar);
        etMonto         = findViewById(R.id.etMonto);
        btnConfirmarPago = findViewById(R.id.btnConfirmarPago);
    }

    /**
     * Configura los listeners de los botones.
     */
    private void setupListeners() {
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnAdjuntar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirGaleria();
            }
        });

        btnConfirmarPago.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmarPago();
            }
        });
    }

    /**
     * Abre la galería del dispositivo para seleccionar una imagen.
     */
    private void abrirGaleria() {
        imagePickerLauncher.launch("image/*");
    }

    /**
     * Muestra la imagen seleccionada en el ImageView y actualiza la etiqueta.
     */
    private void mostrarImagenSeleccionada(Uri uri) {
        ivCaptura.setPadding(0, 0, 0, 0);
        ivCaptura.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ivCaptura.setImageURI(uri);
        tvImageLabel.setText("Captura adjuntada");
        tvImageLabel.setTextColor(getResources().getColor(R.color.accent_orange, getTheme()));

        Log.d(TAG, "Captura de Yappy adjuntada: " + uri.toString());
    }

    /**
     * Valida los campos y genera el JSON de confirmación de pago.
     */
    private void confirmarPago() {
        // ── Validación: Imagen ─────────────────────────────────
        if (imagenSeleccionadaUri == null) {
            Toast.makeText(this, "Debe adjuntar la captura del pago",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // ── Validación: Monto ──────────────────────────────────
        String montoStr = etMonto.getText() != null
                ? etMonto.getText().toString().trim() : "";

        if (montoStr.isEmpty()) {
            Toast.makeText(this, "Ingrese el monto pagado",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        double monto;
        try {
            monto = Double.parseDouble(montoStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Monto inválido",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // ── 1. Guardar los datos en SQLite local y enviarlos al Servidor Apache ──
        List<CartItem> carrito = dbHelper.obtenerCarrito();
        long timestamp = System.currentTimeMillis();

        for (CartItem item : carrito) {
            String restaurante = dbHelper.obtenerNombreEmpresaDeCombo(item.getComboId());
            String nombreComboFormateado = item.getNombreCombo() + " (x" + item.getCantidad() + ")";
            double precioTotalCalculado = item.getPrecio() * item.getCantidad();

            // Guardar localmente en el SQLite del dispositivo móvil
            dbHelper.insertarPedido(nombreComboFormateado, restaurante, precioTotalCalculado);

            // ⚡ NUEVO: Disparar el envío HTTP hacia tu servidor Linux Mint para activar el Trigger de Réplica ⚡
            enviarPedidoAlServidor(nombreComboFormateado, restaurante, precioTotalCalculado);
        }

        // Guardar el pago en la base de datos local (tabla pagos)
        dbHelper.insertarPago("Yappy", monto, imagenSeleccionadaUri.toString(), timestamp, "Verificación Pendiente");

        // ── 2. Generación de los archivos JSON de Pedido y Pago ──
        try {
            // JSON del Pedido (Para el Restaurante)
            JSONObject jsonPedidoRoot = new JSONObject();
            JSONObject jsonPedido = new JSONObject();
            String restauranteName = "Restaurante Local";
            if (!carrito.isEmpty()) {
                restauranteName = dbHelper.obtenerNombreEmpresaDeCombo(carrito.get(0).getComboId());
            }
            jsonPedido.put("restaurante", restauranteName);
            jsonPedido.put("total", totalPago);
            jsonPedido.put("timestamp", timestamp);

            JSONArray jsonItemsArray = new JSONArray();
            for (CartItem item : carrito) {
                JSONObject jsonItem = new JSONObject();
                jsonItem.put("combo_id", item.getComboId());
                jsonItem.put("nombre", item.getNombreCombo());
                jsonItem.put("cantidad", item.getCantidad());
                jsonItem.put("precio_unitario", item.getPrecio());
                jsonItemsArray.put(jsonItem);
            }
            jsonPedido.put("items", jsonItemsArray);
            jsonPedidoRoot.put("PEDIDO_JSON", jsonPedido);

            // JSON del Pago (Para la Empresa del APPS)
            JSONObject jsonPagoRoot = new JSONObject();
            JSONObject jsonPago = new JSONObject();
            jsonPago.put("metodo_pago", "Yappy");
            jsonPago.put("monto", monto);
            jsonPago.put("estado", "Verificación Pendiente");
            jsonPago.put("uri_captura", imagenSeleccionadaUri.toString());
            jsonPago.put("timestamp", timestamp);
            jsonPagoRoot.put("PAGO_JSON", jsonPago);

            // Escribir JSONs en el cache interno de la aplicación
            saveJsonToCache("pedido.json", jsonPedidoRoot.toString(4));
            saveJsonToCache("pago.json", jsonPagoRoot.toString(4));

            Log.d(TAG, "=== ARCHIVOS JSON GENERADOS ===");
            Log.d(TAG, "Pedido JSON:\n" + jsonPedidoRoot.toString(4));
            Log.d(TAG, "Pago JSON:\n" + jsonPagoRoot.toString(4));
            Log.d(TAG, "===============================");

        } catch (JSONException e) {
            Log.e(TAG, "Error al generar JSON de pedido/pago: " + e.getMessage());
        }

        // ── 3. Iniciar el envío secuencial de correos guiado por diálogos ──
        new MaterialAlertDialogBuilder(this)
                .setTitle("Enviar Confirmación de Pedido")
                .setMessage("Por favor, envía el correo de confirmación de pedido al restaurante.")
                .setCancelable(false)
                .setPositiveButton("Enviar Pedido", (dialog, which) -> {
                    launchEmailPedido();
                })
                .show();
    }

    /**
     * Escribe un contenido de texto JSON en un archivo en el directorio de cache.
     */
    private void saveJsonToCache(String filename, String content) {
        try {
            File file = new File(getCacheDir(), filename);
            FileWriter writer = new FileWriter(file);
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            Log.e(TAG, "Error al guardar " + filename + " en cache: " + e.getMessage());
        }
    }

    /**
     * Lanza el primer intent para enviar el correo de confirmación de pedido al restaurante.
     */
    private void launchEmailPedido() {
        try {
            List<CartItem> carrito = dbHelper.obtenerCarrito();
            String restaurante = "Restaurante";
            if (!carrito.isEmpty()) {
                restaurante = dbHelper.obtenerNombreEmpresaDeCombo(carrito.get(0).getComboId());
            }
            String emailRestaurante = restaurante.toLowerCase().replaceAll("[^a-z0-9]", "") + "@chirieats.com";

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("message/rfc822");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{emailRestaurante});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Confirmación de Pedido - ChiriEats");
            intent.putExtra(Intent.EXTRA_TEXT, "Estimado equipo de " + restaurante + ",\n\nAdjuntamos los detalles del nuevo pedido en formato JSON realizado desde la aplicación Chiriquí Eats.\n\nSaludos.");

            File file = new File(getCacheDir(), "pedido.json");
            Uri fileUri = androidx.core.content.FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    file
            );
            intent.putExtra(Intent.EXTRA_STREAM, fileUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            startActivityForResult(Intent.createChooser(intent, "Enviar Confirmación de Pedido al Restaurante"), 1001);
        } catch (Exception e) {
            Log.e(TAG, "Fallo al enviar correo de pedido: " + e.getMessage());
            launchEmailPago();
        }
    }

    /**
     * Lanza el segundo intent para enviar el correo de confirmación de pago a la empresa del app.
     * Adjunta tanto el archivo JSON como la captura del comprobante de pago de Yappy.
     */
    private void launchEmailPago() {
        try {
            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"pagos@chirieats.com"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Confirmación de Pago - ChiriEats");
            intent.putExtra(Intent.EXTRA_TEXT, "Estimado equipo de Chiriquí Eats S.A.,\n\nAdjuntamos los detalles del pago de Yappy en formato JSON, junto con la captura del comprobante adjunto.\n\nSaludos.");

            File file = new File(getCacheDir(), "pago.json");
            Uri fileUri = androidx.core.content.FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    file
            );

            ArrayList<Uri> uris = new ArrayList<>();
            uris.add(fileUri);
            if (imagenSeleccionadaUri != null) {
                uris.add(imagenSeleccionadaUri);
            }

            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            startActivityForResult(Intent.createChooser(intent, "Enviar Confirmación de Pago a Soporte"), 1002);
        } catch (Exception e) {
            Log.e(TAG, "Fallo al enviar correo de pago: " + e.getMessage());
            completarFlujoPago();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("Enviar Comprobante de Pago")
                    .setMessage("Ahora, por favor envía el correo de confirmación de pago con el comprobante y el JSON adjuntos.")
                    .setCancelable(false)
                    .setPositiveButton("Enviar Pago", (dialog, which) -> {
                        launchEmailPago();
                    })
                    .show();
        } else if (requestCode == 1002) {
            completarFlujoPago();
        }
    }

    /**
     * Completa el flujo vaciando el carrito, corriendo los cálculos de impuesto y finalizando la actividad.
     */
    private void completarFlujoPago() {
        simularCalculos(totalPago);
        dbHelper.vaciarCarrito();
        Toast.makeText(this, "Pago confirmado exitosamente", Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }

    /**
     * Simulación de N cálculos (requisito estricto).
     *
     * Ejecuta un bucle for de 1000 iteraciones calculando el impuesto
     * del 7% (ITBMS) sobre el precio del pedido. Toda la lógica del
     * bucle está encapsulada en un bloque try-catch.
     */
    private void simularCalculos(double precio) {
        Log.d(TAG_SIM, "Iniciando simulación de 1000 cálculos de impuesto (7% ITBMS)...");

        try {
            double impuesto = 0;
            for (int i = 1; i <= 1000; i++) {
                impuesto = precio * 0.07;

                if (i % 250 == 0 || i == 1) {
                    Log.d(TAG_SIM, "Iteración " + i +
                            " → Precio: $" + String.format("%.2f", precio) +
                            " | Impuesto 7%: $" + String.format("%.2f", impuesto) +
                            " | Total: $" + String.format("%.2f", precio + impuesto));
                }
            }

            double totalConImpuesto = precio + impuesto;
            Log.d(TAG_SIM, "=== SIMULACIÓN COMPLETADA ===");
            Log.d(TAG_SIM, "Precio base: $" + String.format("%.2f", precio));
            Log.d(TAG_SIM, "Impuesto 7%: $" + String.format("%.2f", impuesto));
            Log.d(TAG_SIM, "Total final: $" + String.format("%.2f", totalConImpuesto));
            Log.d(TAG_SIM, "=============================");

        } catch (Exception e) {
            Log.e(TAG_SIM, "Error en simulación de cálculos: " + e.getMessage());
        }
    }

    /**
     * ── MÉTODO NUEVO DE RED ASÍNCRONA ──
     * Envía de forma transparente los datos de transacciones al servidor Apache de Linux Mint.
     * Al entrar a la base de datos maestra, activa el Trigger relacional de MariaDB de inmediato.
     */
    private void enviarPedidoAlServidor(String nombreCombo, String restaurante, double precio) {
        final String URL_API = "http://10.10.10.29/api_pedidos.php";
        new Thread(() -> {
            java.net.HttpURLConnection conn = null;
            try {
                java.net.URL url = new java.net.URL(URL_API);
                conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setDoOutput(true);
                conn.setConnectTimeout(4000); // Expiración rápida si el servidor no responde

                // Empaquetar la información básica mapeada con la tabla de MariaDB
                JSONObject jsonPedido = new JSONObject();
                jsonPedido.put("nombre_combo", nombreCombo);
                jsonPedido.put("restaurante", restaurante);
                jsonPedido.put("precio", precio);

                // Transferir la cadena binaria del flujo JSON por el aire
                try (java.io.OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonPedido.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Obtener respuesta del servidor para verificar en el Logcat
                int responseCode = conn.getResponseCode();
                Log.d("SERVER_REPLICA", "Conexión Apache establecida. Código: " + responseCode);

            } catch (Exception e) {
                Log.e("SERVER_REPLICA", "El servidor no respondió (Red Local): " + e.getMessage());
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }
}