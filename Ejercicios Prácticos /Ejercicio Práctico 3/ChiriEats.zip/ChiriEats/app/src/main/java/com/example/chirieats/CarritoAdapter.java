package com.example.chirieats;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CarritoAdapter extends RecyclerView.Adapter<CarritoAdapter.ViewHolder> {

    public interface OnCartItemActionListener {
        void onRemoveItem(int position, CartItem item);
    }

    private final List<CartItem> cartItemList;
    private final OnCartItemActionListener listener;

    public CarritoAdapter(List<CartItem> cartItemList, OnCartItemActionListener listener) {
        this.cartItemList = cartItemList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_carrito, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CartItem item = cartItemList.get(position);
        holder.tvNombre.setText(item.getNombreCombo() + " x" + item.getCantidad());
        holder.tvPrecio.setText(String.format("Subtotal: $%.2f", item.getPrecio() * item.getCantidad()));

        if (item.getFotoUri() != null && !item.getFotoUri().isEmpty()) {
            holder.ivFoto.setImageURI(Uri.parse(item.getFotoUri()));
        } else {
            holder.ivFoto.setImageResource(R.drawable.ic_food);
        }

        holder.btnRemove.setOnClickListener(v -> {
            int adapterPosition = holder.getBindingAdapterPosition();
            if (adapterPosition != RecyclerView.NO_POSITION) {
                listener.onRemoveItem(adapterPosition, item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartItemList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivFoto;
        final TextView tvNombre;
        final TextView tvPrecio;
        final ImageButton btnRemove;

        ViewHolder(View itemView) {
            super(itemView);
            ivFoto = itemView.findViewById(R.id.ivCartItem);
            tvNombre = itemView.findViewById(R.id.tvNombreCartItem);
            tvPrecio = itemView.findViewById(R.id.tvPrecioCartItem);
            btnRemove = itemView.findViewById(R.id.btnRemoveCartItem);
        }
    }
}
