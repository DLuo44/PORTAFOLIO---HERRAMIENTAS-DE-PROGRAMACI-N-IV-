package com.example.chirieats;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter para el RecyclerView de combos/menú de una empresa.
 */
public class ComboAdapter extends RecyclerView.Adapter<ComboAdapter.ComboViewHolder> {

    /**
     * Interfaz de callback para manejar las acciones sobre cada combo.
     */
    public interface OnComboActionListener {
        void onEdit(int position);
        void onDelete(int position);
    }

    private final List<Combo> comboList;
    private final OnComboActionListener listener;

    /**
     * Constructor del adapter.
     *
     * @param comboList Lista de combos a mostrar.
     * @param listener  Listener para las acciones de editar/eliminar.
     */
    public ComboAdapter(List<Combo> comboList, OnComboActionListener listener) {
        this.comboList = comboList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ComboViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_combo, parent, false);
        return new ComboViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ComboViewHolder holder, int position) {
        Combo combo = comboList.get(position);
        holder.tvNombre.setText(combo.getNombre());
        holder.tvContenido.setText(combo.getContenido() != null ? combo.getContenido() : "");
        holder.tvPrecio.setText(String.format("$%.2f", combo.getPrecio()));

        if (combo.getFotoUri() != null && !combo.getFotoUri().isEmpty()) {
            holder.ivFoto.setImageURI(Uri.parse(combo.getFotoUri()));
        } else {
            holder.ivFoto.setImageResource(R.drawable.ic_food);
        }

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getBindingAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    listener.onEdit(adapterPosition);
                }
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getBindingAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    listener.onDelete(adapterPosition);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return comboList.size();
    }

    /**
     * ViewHolder que mantiene las referencias a las vistas de cada ítem de combo.
     */
    static class ComboViewHolder extends RecyclerView.ViewHolder {

        final ImageView ivFoto;
        final TextView tvNombre;
        final TextView tvContenido;
        final TextView tvPrecio;
        final ImageButton btnEdit;
        final ImageButton btnDelete;

        ComboViewHolder(@NonNull View itemView) {
            super(itemView);
            ivFoto = itemView.findViewById(R.id.ivComboFoto);
            tvNombre = itemView.findViewById(R.id.tvNombreCombo);
            tvContenido = itemView.findViewById(R.id.tvContenidoCombo);
            tvPrecio = itemView.findViewById(R.id.tvPrecioCombo);
            btnEdit  = itemView.findViewById(R.id.btnEditCombo);
            btnDelete = itemView.findViewById(R.id.btnDeleteCombo);
        }
    }
}
