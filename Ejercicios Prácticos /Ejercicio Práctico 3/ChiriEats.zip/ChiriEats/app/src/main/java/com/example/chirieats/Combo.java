package com.example.chirieats;

/**
 * Modelo que representa un combo o producto del menú de una empresa.
 */
public class Combo {

    private long id;
    private long empresaId;
    private String nombre;
    private String contenido;
    private String fotoUri;
    private double precio;

    /**
     * Constructor con todos los campos.
     *
     * @param id        ID único del combo.
     * @param empresaId ID de la empresa a la que pertenece este combo.
     * @param nombre    Nombre del combo.
     * @param contenido Descripción de lo que trae el combo.
     * @param fotoUri   Ruta URI de la foto del combo.
     * @param precio    Precio del combo.
     */
    public Combo(long id, long empresaId, String nombre, String contenido, String fotoUri, double precio) {
        this.id = id;
        this.empresaId = empresaId;
        this.nombre = nombre;
        this.contenido = contenido;
        this.fotoUri = fotoUri;
        this.precio = precio;
    }

    /**
     * Constructor sin ID (se le asigna -1 por defecto).
     *
     * @param empresaId ID de la empresa a la que pertenece este combo.
     * @param nombre    Nombre del combo.
     * @param contenido Descripción de lo que trae el combo.
     * @param fotoUri   Ruta URI de la foto del combo.
     * @param precio    Precio del combo.
     */
    public Combo(long empresaId, String nombre, String contenido, String fotoUri, double precio) {
        this(-1, empresaId, nombre, contenido, fotoUri, precio);
    }

    // ── Getters & Setters ──────────────────────────────────────

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getEmpresaId() {
        return empresaId;
    }

    public void setEmpresaId(long empresaId) {
        this.empresaId = empresaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public String getFotoUri() {
        return fotoUri;
    }

    public void setFotoUri(String fotoUri) {
        this.fotoUri = fotoUri;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
