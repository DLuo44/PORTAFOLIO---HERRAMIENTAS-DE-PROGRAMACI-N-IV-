package com.example.chirieats;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper — Gestiona la base de datos local SQLite
 * para Chiriquí Eats S.A.
 *
 * Tablas:
 *   - pedidos_locales: id, nombre_combo, restaurante, precio
 *   - empresas: id, nombre, descripcion
 *   - combos: id, empresa_id, nombre, contenido, foto_uri, precio
 *   - carrito: id, combo_id, nombre_combo, precio, foto_uri, cantidad
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // ── Constantes de la base de datos ─────────────────────────
    private static final String DATABASE_NAME    = "chirieats.db";
    private static final int    DATABASE_VERSION = 6;

    // ── Tabla: pagos ─────────────────────────────────────────────
    public static final String TABLE_PAGOS            = "pagos";
    public static final String COL_PAGO_ID            = "id";
    public static final String COL_PAGO_METODO        = "metodo_pago";
    public static final String COL_PAGO_MONTO         = "monto";
    public static final String COL_PAGO_CAPTURA_URI   = "uri_captura";
    public static final String COL_PAGO_TIMESTAMP     = "timestamp";
    public static final String COL_PAGO_ESTADO        = "estado";

    // ── Tabla: pedidos_locales ──────────────────────────────────
    public static final String TABLE_PEDIDOS         = "pedidos_locales";
    public static final String COL_ID                = "id";
    public static final String COL_NOMBRE_COMBO      = "nombre_combo";
    public static final String COL_RESTAURANTE       = "restaurante";
    public static final String COL_PRECIO            = "precio";

    // ── Tabla: empresas ─────────────────────────────────────────
    public static final String TABLE_EMPRESAS        = "empresas";
    public static final String COL_EMPRESA_ID        = "id";
    public static final String COL_EMPRESA_NOM       = "nombre";
    public static final String COL_EMPRESA_DESC      = "descripcion";

    // ── Tabla: combos ───────────────────────────────────────────
    public static final String TABLE_COMBOS          = "combos";
    public static final String COL_COMBO_ID          = "id";
    public static final String COL_COMBO_EMP_ID      = "empresa_id";
    public static final String COL_COMBO_NOM         = "nombre";
    public static final String COL_COMBO_CONTENIDO   = "contenido";
    public static final String COL_COMBO_FOTO_URI    = "foto_uri";
    public static final String COL_COMBO_PRECIO      = "precio";

    // ── Tabla: carrito ──────────────────────────────────────────
    public static final String TABLE_CARRITO         = "carrito";
    public static final String COL_CARRITO_ID        = "id";
    public static final String COL_CARRITO_COMBO_ID  = "combo_id";
    public static final String COL_CARRITO_NOMBRE    = "nombre_combo";
    public static final String COL_CARRITO_PRECIO    = "precio";
    public static final String COL_CARRITO_FOTO_URI  = "foto_uri";
    public static final String COL_CARRITO_CANTIDAD  = "cantidad";

    // ── SQL de creación ────────────────────────────────────────
    private static final String SQL_CREATE_PEDIDOS =
            "CREATE TABLE " + TABLE_PEDIDOS + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_NOMBRE_COMBO + " TEXT, " +
                    COL_RESTAURANTE + " TEXT, " +
                    COL_PRECIO + " REAL)";

    private static final String SQL_CREATE_EMPRESAS =
            "CREATE TABLE " + TABLE_EMPRESAS + " (" +
                    COL_EMPRESA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_EMPRESA_NOM + " TEXT, " +
                    COL_EMPRESA_DESC + " TEXT)";

    private static final String SQL_CREATE_COMBOS =
            "CREATE TABLE " + TABLE_COMBOS + " (" +
                    COL_COMBO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_COMBO_EMP_ID + " INTEGER, " +
                    COL_COMBO_NOM + " TEXT, " +
                    COL_COMBO_CONTENIDO + " TEXT, " +
                    COL_COMBO_FOTO_URI + " TEXT, " +
                    COL_COMBO_PRECIO + " REAL)";

    private static final String SQL_CREATE_CARRITO =
            "CREATE TABLE " + TABLE_CARRITO + " (" +
                    COL_CARRITO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_CARRITO_COMBO_ID + " INTEGER, " +
                    COL_CARRITO_NOMBRE + " TEXT, " +
                    COL_CARRITO_PRECIO + " REAL, " +
                    COL_CARRITO_FOTO_URI + " TEXT, " +
                    COL_CARRITO_CANTIDAD + " INTEGER)";

    private static final String SQL_CREATE_PAGOS =
            "CREATE TABLE " + TABLE_PAGOS + " (" +
                    COL_PAGO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_PAGO_METODO + " TEXT, " +
                    COL_PAGO_MONTO + " REAL, " +
                    COL_PAGO_CAPTURA_URI + " TEXT, " +
                    COL_PAGO_TIMESTAMP + " INTEGER, " +
                    COL_PAGO_ESTADO + " TEXT)";

    /**
     * Constructor.
     *
     * @param context Contexto de la aplicación.
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_PEDIDOS);
        db.execSQL(SQL_CREATE_EMPRESAS);
        db.execSQL(SQL_CREATE_COMBOS);
        db.execSQL(SQL_CREATE_CARRITO);
        db.execSQL(SQL_CREATE_PAGOS);
        precargarEmpresasDefault(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 6) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_PEDIDOS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPRESAS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMBOS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_CARRITO);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_PAGOS);
            onCreate(db);
        }
    }

    private void precargarEmpresasDefault(SQLiteDatabase db) {
        ContentValues v1 = new ContentValues();
        v1.put(COL_EMPRESA_NOM, "KFC");
        v1.put(COL_EMPRESA_DESC, "Pollo frito, combos y comida rápida");
        db.insert(TABLE_EMPRESAS, null, v1);

        ContentValues v2 = new ContentValues();
        v2.put(COL_EMPRESA_NOM, "McDonald's");
        v2.put(COL_EMPRESA_DESC, "Hamburguesas, papas fritas y postres");
        db.insert(TABLE_EMPRESAS, null, v2);
    }

    // ── Operaciones CRUD Pedidos ────────────────────────────────

    public long insertarPedido(String nombreCombo, String restaurante, double precio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NOMBRE_COMBO, nombreCombo);
        values.put(COL_RESTAURANTE, restaurante);
        values.put(COL_PRECIO, precio);

        long result = db.insert(TABLE_PEDIDOS, null, values);
        db.close();
        return result;
    }

    // ── Operaciones CRUD Empresas ───────────────────────────────

    public long insertarEmpresa(String nombre, String descripcion) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EMPRESA_NOM, nombre);
        values.put(COL_EMPRESA_DESC, descripcion);

        long id = db.insert(TABLE_EMPRESAS, null, values);
        db.close();
        return id;
    }

    public boolean actualizarEmpresa(long id, String nombre, String descripcion) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EMPRESA_NOM, nombre);
        values.put(COL_EMPRESA_DESC, descripcion);

        int rows = db.update(TABLE_EMPRESAS, values, COL_EMPRESA_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public boolean eliminarEmpresa(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_COMBOS, COL_COMBO_EMP_ID + "=?", new String[]{String.valueOf(id)});
        int rows = db.delete(TABLE_EMPRESAS, COL_EMPRESA_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public List<Empresa> obtenerEmpresas() {
        List<Empresa> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EMPRESAS, null, null, null, null, null, COL_EMPRESA_NOM + " ASC");

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndex(COL_EMPRESA_ID);
                int nomIndex = cursor.getColumnIndex(COL_EMPRESA_NOM);
                int descIndex = cursor.getColumnIndex(COL_EMPRESA_DESC);

                do {
                    long id = cursor.getLong(idIndex);
                    String nom = cursor.getString(nomIndex);
                    String desc = cursor.getString(descIndex);
                    lista.add(new Empresa(id, nom, desc));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
        db.close();
        return lista;
    }

    // ── Operaciones CRUD Combos ─────────────────────────────────

    public long insertarCombo(long empresaId, String nombre, String contenido, String fotoUri, double precio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_COMBO_EMP_ID, empresaId);
        values.put(COL_COMBO_NOM, nombre);
        values.put(COL_COMBO_CONTENIDO, contenido);
        values.put(COL_COMBO_FOTO_URI, fotoUri);
        values.put(COL_COMBO_PRECIO, precio);

        long id = db.insert(TABLE_COMBOS, null, values);
        db.close();
        return id;
    }

    public boolean actualizarCombo(long id, String nombre, String contenido, String fotoUri, double precio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_COMBO_NOM, nombre);
        values.put(COL_COMBO_CONTENIDO, contenido);
        values.put(COL_COMBO_FOTO_URI, fotoUri);
        values.put(COL_COMBO_PRECIO, precio);

        int rows = db.update(TABLE_COMBOS, values, COL_COMBO_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public boolean eliminarCombo(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_COMBOS, COL_COMBO_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public List<Combo> obtenerCombosPorEmpresa(long empresaId) {
        List<Combo> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_COMBOS, null, COL_COMBO_EMP_ID + "=?",
                new String[]{String.valueOf(empresaId)}, null, null, COL_COMBO_NOM + " ASC");

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndex(COL_COMBO_ID);
                int empIdIndex = cursor.getColumnIndex(COL_COMBO_EMP_ID);
                int nomIndex = cursor.getColumnIndex(COL_COMBO_NOM);
                int contenidoIndex = cursor.getColumnIndex(COL_COMBO_CONTENIDO);
                int fotoUriIndex = cursor.getColumnIndex(COL_COMBO_FOTO_URI);
                int precioIndex = cursor.getColumnIndex(COL_COMBO_PRECIO);

                do {
                    long id = cursor.getLong(idIndex);
                    long empId = cursor.getLong(empIdIndex);
                    String nom = cursor.getString(nomIndex);
                    String contenido = cursor.getString(contenidoIndex);
                    String fotoUri = cursor.getString(fotoUriIndex);
                    double precio = cursor.getDouble(precioIndex);
                    lista.add(new Combo(id, empId, nom, contenido, fotoUri, precio));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
        db.close();
        return lista;
    }

    // ── Operaciones CRUD Carrito ────────────────────────────────

    public long insertarCarrito(CartItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_CARRITO_COMBO_ID, item.getComboId());
        values.put(COL_CARRITO_NOMBRE, item.getNombreCombo());
        values.put(COL_CARRITO_PRECIO, item.getPrecio());
        values.put(COL_CARRITO_FOTO_URI, item.getFotoUri());
        values.put(COL_CARRITO_CANTIDAD, item.getCantidad());

        long id = db.insert(TABLE_CARRITO, null, values);
        db.close();
        return id;
    }

    public List<CartItem> obtenerCarrito() {
        List<CartItem> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_CARRITO, null, null, null, null, null, COL_CARRITO_ID + " ASC");

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndex(COL_CARRITO_ID);
                int comboIdIndex = cursor.getColumnIndex(COL_CARRITO_COMBO_ID);
                int nombreIndex = cursor.getColumnIndex(COL_CARRITO_NOMBRE);
                int precioIndex = cursor.getColumnIndex(COL_CARRITO_PRECIO);
                int fotoUriIndex = cursor.getColumnIndex(COL_CARRITO_FOTO_URI);
                int cantidadIndex = cursor.getColumnIndex(COL_CARRITO_CANTIDAD);

                do {
                    long id = cursor.getLong(idIndex);
                    long comboId = cursor.getLong(comboIdIndex);
                    String nombre = cursor.getString(nombreIndex);
                    double precio = cursor.getDouble(precioIndex);
                    String fotoUri = cursor.getString(fotoUriIndex);
                    int cantidad = cursor.getInt(cantidadIndex);
                    lista.add(new CartItem(id, comboId, nombre, precio, fotoUri, cantidad));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
        db.close();
        return lista;
    }

    public boolean eliminarItemCarrito(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_CARRITO, COL_CARRITO_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public void vaciarCarrito() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CARRITO, null, null);
        db.close();
    }

    // ── Operaciones CRUD Pagos y Sincronización ──────────────────

    public long insertarPago(String metodo, double monto, String uriCaptura, long timestamp, String estado) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_PAGO_METODO, metodo);
        values.put(COL_PAGO_MONTO, monto);
        values.put(COL_PAGO_CAPTURA_URI, uriCaptura);
        values.put(COL_PAGO_TIMESTAMP, timestamp);
        values.put(COL_PAGO_ESTADO, estado);
        long id = db.insert(TABLE_PAGOS, null, values);
        db.close();
        return id;
    }

    public String obtenerNombreEmpresaDeCombo(long comboId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String nombre = "Restaurante Local";
        String query = "SELECT e." + COL_EMPRESA_NOM + " FROM " + TABLE_EMPRESAS + " e " +
                       " JOIN " + TABLE_COMBOS + " c ON e." + COL_EMPRESA_ID + " = c." + COL_COMBO_EMP_ID +
                       " WHERE c." + COL_COMBO_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(comboId)});
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                nombre = cursor.getString(0);
            }
            cursor.close();
        }
        db.close();
        return nombre;
    }
}

