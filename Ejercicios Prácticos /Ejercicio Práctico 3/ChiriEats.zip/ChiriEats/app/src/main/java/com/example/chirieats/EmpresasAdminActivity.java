package com.example.chirieats;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

/**
 * EmpresasAdminActivity — Gestión de Empresas (CRUD).
 *
 * Muestra un directorio de empresas con operaciones de
 * Crear, Leer, Actualizar y Eliminar.
 */
public class EmpresasAdminActivity extends AppCompatActivity
        implements EmpresaAdapter.OnEmpresaActionListener {

    private RecyclerView rvEmpresas;
    private FloatingActionButton fabAdd;
    private ImageButton btnBack;
    private LinearLayout layoutEmpty;

    private List<Empresa> empresaList;
    private EmpresaAdapter adapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empresas_admin);

        dbHelper = new DatabaseHelper(this);

        initViews();
        initData();
        setupRecyclerView();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatos();
    }

    /**
     * Enlaza las vistas del layout.
     */
    private void initViews() {
        rvEmpresas  = findViewById(R.id.rvEmpresas);
        fabAdd      = findViewById(R.id.fabAdd);
        btnBack     = findViewById(R.id.btnBack);
        layoutEmpty = findViewById(R.id.layoutEmpty);
    }

    /**
     * Inicializa la lista vacía.
     */
    private void initData() {
        empresaList = new ArrayList<>();
    }

    /**
     * Carga los datos desde SQLite.
     */
    private void cargarDatos() {
        empresaList.clear();
        empresaList.addAll(dbHelper.obtenerEmpresas());
        adapter.notifyDataSetChanged();
        updateEmptyState();
    }

    /**
     * Configura el RecyclerView con su LayoutManager y Adapter.
     */
    private void setupRecyclerView() {
        adapter = new EmpresaAdapter(empresaList, this);
        rvEmpresas.setLayoutManager(new LinearLayoutManager(this));
        rvEmpresas.setAdapter(adapter);
    }

    /**
     * Configura los listeners del FAB y botón de retroceso.
     */
    private void setupListeners() {
        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEmpresaDialog(-1);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // ── OnEmpresaActionListener ────────────────────────────────

    @Override
    public void onEdit(int position) {
        showEmpresaDialog(position);
    }

    @Override
    public void onDelete(int position) {
        Empresa empresa = empresaList.get(position);
        new MaterialAlertDialogBuilder(this)
                .setTitle(getString(R.string.dialog_delete_title))
                .setMessage(getString(R.string.dialog_delete_message, empresa.getNombre()))
                .setNegativeButton(getString(R.string.btn_cancel), null)
                .setPositiveButton(getString(R.string.btn_delete), (dialog, which) -> {
                    boolean deleted = dbHelper.eliminarEmpresa(empresa.getId());
                    if (deleted) {
                        empresaList.remove(position);
                        adapter.notifyItemRemoved(position);
                        adapter.notifyItemRangeChanged(position, empresaList.size());
                        updateEmptyState();
                        Toast.makeText(this,
                                getString(R.string.toast_deleted), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error al eliminar empresa", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    @Override
    public void onItemClick(int position) {
        Empresa empresa = empresaList.get(position);
        android.content.Intent intent = new android.content.Intent(this, CombosAdminActivity.class);
        intent.putExtra("empresa_id", empresa.getId());
        intent.putExtra("empresa_nombre", empresa.getNombre());
        startActivity(intent);
    }

    // ── Dialog de Crear / Editar ───────────────────────────────

    /**
     * Muestra un AlertDialog con campos para crear o editar una empresa.
     *
     * @param position Posición del ítem a editar, o -1 para crear uno nuevo.
     */
    private void showEmpresaDialog(int position) {
        boolean isEdit = position >= 0;

        // Inflar la vista personalizada del dialog
        View dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_empresa, null);

        TextView tvDialogTitle = dialogView.findViewById(R.id.tvDialogTitle);
        TextInputEditText etNombre = dialogView.findViewById(R.id.etNombre);
        TextInputEditText etDescripcion = dialogView.findViewById(R.id.etDescripcion);

        // Configurar título y datos previos si es edición
        if (isEdit) {
            tvDialogTitle.setText(R.string.dialog_empresa_title_edit);
            Empresa empresa = empresaList.get(position);
            etNombre.setText(empresa.getNombre());
            etDescripcion.setText(empresa.getDescripcion());
        } else {
            tvDialogTitle.setText(R.string.dialog_empresa_title_add);
        }

        new MaterialAlertDialogBuilder(this)
                .setView(dialogView)
                .setNegativeButton(getString(R.string.btn_cancel), null)
                .setPositiveButton(getString(R.string.btn_save), (dialog, which) -> {
                    String nombre = etNombre.getText() != null
                            ? etNombre.getText().toString().trim() : "";
                    String descripcion = etDescripcion.getText() != null
                            ? etDescripcion.getText().toString().trim() : "";

                    if (nombre.isEmpty()) {
                        Toast.makeText(this,
                                getString(R.string.toast_nombre_required),
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (isEdit) {
                        // Actualizar empresa existente
                        Empresa empresa = empresaList.get(position);
                        boolean updated = dbHelper.actualizarEmpresa(empresa.getId(), nombre, descripcion);
                        if (updated) {
                            empresa.setNombre(nombre);
                            empresa.setDescripcion(descripcion);
                            adapter.notifyItemChanged(position);
                            Toast.makeText(this,
                                    getString(R.string.toast_updated),
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Crear nueva empresa en la DB
                        long id = dbHelper.insertarEmpresa(nombre, descripcion);
                        if (id != -1) {
                            empresaList.add(new Empresa(id, nombre, descripcion));
                            adapter.notifyItemInserted(empresaList.size() - 1);
                            rvEmpresas.smoothScrollToPosition(empresaList.size() - 1);
                            Toast.makeText(this,
                                    getString(R.string.toast_created),
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Error al crear empresa", Toast.LENGTH_SHORT).show();
                        }
                    }
                    updateEmptyState();
                })
                .show();
    }

    // ── Estado vacío ───────────────────────────────────────────

    /**
     * Muestra u oculta el mensaje de estado vacío según la lista.
     */
    private void updateEmptyState() {
        if (empresaList.isEmpty()) {
            layoutEmpty.setVisibility(View.VISIBLE);
            rvEmpresas.setVisibility(View.GONE);
        } else {
            layoutEmpty.setVisibility(View.GONE);
            rvEmpresas.setVisibility(View.VISIBLE);
        }
    }
}
