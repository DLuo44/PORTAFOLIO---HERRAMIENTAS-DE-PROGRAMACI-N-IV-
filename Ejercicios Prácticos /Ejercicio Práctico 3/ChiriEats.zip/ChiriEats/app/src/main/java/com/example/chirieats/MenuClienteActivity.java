package com.example.chirieats;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.List;

public class MenuClienteActivity extends AppCompatActivity implements MenuClienteAdapter.OnComboClickListener {

    private long empresaId;
    private String empresaNombre;

    private RecyclerView rvCombos;
    private ImageButton btnBack;
    private ImageButton btnCart;
    private TextView tvToolbarTitle;
    private LinearLayout layoutEmptyCombos;

    private List<Combo> comboList;
    private MenuClienteAdapter adapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_cliente);

        dbHelper = new DatabaseHelper(this);

        empresaId = getIntent().getLongExtra("empresa_id", -1);
        empresaNombre = getIntent().getStringExtra("empresa_nombre");

        if (empresaId == -1) {
            Toast.makeText(this, "Empresa no válida", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        initData();
        setupRecyclerView();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatos();
    }

    private void initViews() {
        rvCombos          = findViewById(R.id.rvCombos);
        btnBack           = findViewById(R.id.btnBack);
        btnCart           = findViewById(R.id.btnCart);
        tvToolbarTitle    = findViewById(R.id.tvToolbarTitle);
        layoutEmptyCombos = findViewById(R.id.layoutEmptyCombos);

        if (empresaNombre != null && !empresaNombre.isEmpty()) {
            tvToolbarTitle.setText("Menú - " + empresaNombre);
        } else {
            tvToolbarTitle.setText("Menú");
        }
    }

    private void initData() {
        comboList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        adapter = new MenuClienteAdapter(comboList, this);
        rvCombos.setLayoutManager(new LinearLayoutManager(this));
        rvCombos.setAdapter(adapter);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());
        btnCart.setOnClickListener(v -> {
            Intent intent = new Intent(this, CarritoActivity.class);
            startActivity(intent);
        });
    }

    private void cargarDatos() {
        comboList.clear();
        comboList.addAll(dbHelper.obtenerCombosPorEmpresa(empresaId));
        adapter.notifyDataSetChanged();

        if (comboList.isEmpty()) {
            layoutEmptyCombos.setVisibility(View.VISIBLE);
            rvCombos.setVisibility(View.GONE);
        } else {
            layoutEmptyCombos.setVisibility(View.GONE);
            rvCombos.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onComboClick(Combo combo) {
        showAddToCartDialog(combo);
    }

    private void showAddToCartDialog(Combo combo) {
        View dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_add_to_cart, null);

        TextView tvComboNameCart = dialogView.findViewById(R.id.tvComboNameCart);
        TextView tvComboPriceCart = dialogView.findViewById(R.id.tvComboPriceCart);
        TextView tvQuantity = dialogView.findViewById(R.id.tvQuantity);
        ImageButton btnMinus = dialogView.findViewById(R.id.btnMinus);
        ImageButton btnPlus = dialogView.findViewById(R.id.btnPlus);

        tvComboNameCart.setText(combo.getNombre());
        tvComboPriceCart.setText(String.format("$%.2f", combo.getPrecio()));

        final int[] quantity = {1};

        btnMinus.setOnClickListener(v -> {
            if (quantity[0] > 1) {
                quantity[0]--;
                tvQuantity.setText(String.valueOf(quantity[0]));
            }
        });

        btnPlus.setOnClickListener(v -> {
            quantity[0]++;
            tvQuantity.setText(String.valueOf(quantity[0]));
        });

        new MaterialAlertDialogBuilder(this)
                .setView(dialogView)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Añadir", (dialog, which) -> {
                    CartItem cartItem = new CartItem(combo.getId(), combo.getNombre(), combo.getPrecio(), combo.getFotoUri(), quantity[0]);
                    long id = dbHelper.insertarCarrito(cartItem);
                    if (id != -1) {
                        Toast.makeText(this, "Añadido al carrito", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error al añadir al carrito", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }
}
