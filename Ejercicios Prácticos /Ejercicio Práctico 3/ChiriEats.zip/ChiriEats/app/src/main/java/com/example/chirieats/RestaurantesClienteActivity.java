package com.example.chirieats;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * RestaurantesClienteActivity — Directorio de restaurantes para clientes.
 */
public class RestaurantesClienteActivity extends AppCompatActivity implements RestauranteClienteAdapter.OnRestauranteClickListener {

    private RecyclerView rvRestaurantes;
    private ImageButton btnBack;
    private LinearLayout layoutEmpty;

    private List<Empresa> empresaList;
    private RestauranteClienteAdapter adapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurantes_cliente);

        dbHelper = new DatabaseHelper(this);

        initViews();
        initData();
        setupRecyclerView();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatos();
    }

    private void initViews() {
        rvRestaurantes = findViewById(R.id.rvRestaurantes);
        btnBack        = findViewById(R.id.btnBack);
        layoutEmpty    = findViewById(R.id.layoutEmpty);
    }

    private void initData() {
        empresaList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        adapter = new RestauranteClienteAdapter(empresaList, this);
        rvRestaurantes.setLayoutManager(new LinearLayoutManager(this));
        rvRestaurantes.setAdapter(adapter);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());
    }

    private void cargarDatos() {
        empresaList.clear();
        empresaList.addAll(dbHelper.obtenerEmpresas());
        adapter.notifyDataSetChanged();
        
        if (empresaList.isEmpty()) {
            layoutEmpty.setVisibility(View.VISIBLE);
            rvRestaurantes.setVisibility(View.GONE);
        } else {
            layoutEmpty.setVisibility(View.GONE);
            rvRestaurantes.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onRestauranteClick(Empresa empresa) {
        Intent intent = new Intent(this, MenuClienteActivity.class);
        intent.putExtra("empresa_id", empresa.getId());
        intent.putExtra("empresa_nombre", empresa.getNombre());
        startActivity(intent);
    }
}
