package com.example.chirieats;

/**
 * Modelo que representa una empresa (restaurante / proveedor)
 * en el directorio de Chiriquí Eats S.A.
 */
public class Empresa {

    private long id;
    private String nombre;
    private String descripcion;

    /**
     * Constructor con ID.
     *
     * @param id          ID único de la empresa (generalmente de la base de datos).
     * @param nombre      Nombre de la empresa.
     * @param descripcion Breve descripción del negocio.
     */
    public Empresa(long id, String nombre, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    /**
     * Constructor sin ID (se le asigna -1 por defecto).
     *
     * @param nombre      Nombre de la empresa.
     * @param descripcion Breve descripción del negocio.
     */
    public Empresa(String nombre, String descripcion) {
        this(-1, nombre, descripcion);
    }

    // ── Getters & Setters ──────────────────────────────────────

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}

