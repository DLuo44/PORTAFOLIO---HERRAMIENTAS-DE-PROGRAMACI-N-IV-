package com.example.chirieats;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RestauranteClienteAdapter extends RecyclerView.Adapter<RestauranteClienteAdapter.ViewHolder> {

    public interface OnRestauranteClickListener {
        void onRestauranteClick(Empresa empresa);
    }

    private final List<Empresa> empresaList;
    private final OnRestauranteClickListener listener;

    public RestauranteClienteAdapter(List<Empresa> empresaList, OnRestauranteClickListener listener) {
        this.empresaList = empresaList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_restaurante_cliente, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Empresa empresa = empresaList.get(position);
        holder.tvNombre.setText(empresa.getNombre());
        holder.tvDescripcion.setText(empresa.getDescripcion());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onRestauranteClick(empresa);
            }
        });
    }

    @Override
    public int getItemCount() {
        return empresaList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView tvNombre;
        final TextView tvDescripcion;

        ViewHolder(View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombreRestaurante);
            tvDescripcion = itemView.findViewById(R.id.tvDescripcion);
        }
    }
}
