package com.example.chirieats;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class ClienteDashboardActivity extends AppCompatActivity {

    private ImageButton btnBack;
    private MaterialCardView cardRestaurantes;
    private MaterialCardView cardCarrito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente_dashboard);

        initViews();
        setupListeners();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        cardRestaurantes = findViewById(R.id.cardRestaurantes);
        cardCarrito = findViewById(R.id.cardCarrito);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        cardRestaurantes.setOnClickListener(v -> {
            Intent intent = new Intent(ClienteDashboardActivity.this, RestaurantesClienteActivity.class);
            startActivity(intent);
        });

        cardCarrito.setOnClickListener(v -> {
            Intent intent = new Intent(ClienteDashboardActivity.this, CarritoActivity.class);
            startActivity(intent);
        });
    }
}
