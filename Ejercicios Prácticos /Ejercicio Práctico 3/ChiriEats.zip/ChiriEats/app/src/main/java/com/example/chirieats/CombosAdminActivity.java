package com.example.chirieats;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

/**
 * CombosAdminActivity — Pantalla de gestión de combos para un restaurante.
 */
public class CombosAdminActivity extends AppCompatActivity
        implements ComboAdapter.OnComboActionListener {

    private long empresaId;
    private String empresaNombre;

    private RecyclerView rvCombos;
    private FloatingActionButton fabAddCombo;
    private ImageButton btnBack;
    private TextView tvToolbarTitle;
    private LinearLayout layoutEmptyCombos;

    private List<Combo> comboList;
    private ComboAdapter adapter;
    private DatabaseHelper dbHelper;

    // Para la selección de imagen
    private ImageView ivCurrentDialogPhoto;
    private String currentDialogPhotoUri = "";

    private ActivityResultLauncher<Intent> photoPickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combos_admin);

        dbHelper = new DatabaseHelper(this);

        empresaId = getIntent().getLongExtra("empresa_id", -1);
        empresaNombre = getIntent().getStringExtra("empresa_nombre");

        if (empresaId == -1) {
            Toast.makeText(this, "Empresa no válida", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        initData();
        setupRecyclerView();
        setupListeners();
        
        photoPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri selectedImageUri = result.getData().getData();
                        if (selectedImageUri != null) {
                            currentDialogPhotoUri = selectedImageUri.toString();
                            if (ivCurrentDialogPhoto != null) {
                                ivCurrentDialogPhoto.setImageURI(selectedImageUri);
                            }
                        }
                    }
                }
        );

        cargarDatos();
    }

    private void initViews() {
        rvCombos          = findViewById(R.id.rvCombos);
        fabAddCombo       = findViewById(R.id.fabAddCombo);
        btnBack           = findViewById(R.id.btnBack);
        tvToolbarTitle    = findViewById(R.id.tvToolbarTitle);
        layoutEmptyCombos = findViewById(R.id.layoutEmptyCombos);

        if (empresaNombre != null && !empresaNombre.isEmpty()) {
            tvToolbarTitle.setText("Menú - " + empresaNombre);
        } else {
            tvToolbarTitle.setText("Menú de Combos");
        }
    }

    private void initData() {
        comboList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        adapter = new ComboAdapter(comboList, this);
        rvCombos.setLayoutManager(new LinearLayoutManager(this));
        rvCombos.setAdapter(adapter);
    }

    private void setupListeners() {
        fabAddCombo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showComboDialog(-1);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void cargarDatos() {
        comboList.clear();
        comboList.addAll(dbHelper.obtenerCombosPorEmpresa(empresaId));
        adapter.notifyDataSetChanged();
        updateEmptyState();
    }

    private void updateEmptyState() {
        if (comboList.isEmpty()) {
            layoutEmptyCombos.setVisibility(View.VISIBLE);
            rvCombos.setVisibility(View.GONE);
        } else {
            layoutEmptyCombos.setVisibility(View.GONE);
            rvCombos.setVisibility(View.VISIBLE);
        }
    }

    // ── OnComboActionListener ──────────────────────────────────

    @Override
    public void onEdit(int position) {
        showComboDialog(position);
    }

    @Override
    public void onDelete(int position) {
        Combo combo = comboList.get(position);
        new MaterialAlertDialogBuilder(this)
                .setTitle("Eliminar combo")
                .setMessage("¿Desea eliminar el combo '" + combo.getNombre() + "' del menú?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", (dialog, which) -> {
                    boolean deleted = dbHelper.eliminarCombo(combo.getId());
                    if (deleted) {
                        comboList.remove(position);
                        adapter.notifyItemRemoved(position);
                        adapter.notifyItemRangeChanged(position, comboList.size());
                        updateEmptyState();
                        Toast.makeText(this, "Combo eliminado", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error al eliminar combo", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    // ── Dialog de Crear / Editar Combo ─────────────────────────

    private void showComboDialog(int position) {
        boolean isEdit = position >= 0;
        currentDialogPhotoUri = "";

        View dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_combo, null);

        TextView tvDialogTitleCombo = dialogView.findViewById(R.id.tvDialogTitleCombo);
        TextInputEditText etNombreCombo = dialogView.findViewById(R.id.etNombreCombo);
        TextInputEditText etContenidoCombo = dialogView.findViewById(R.id.etContenidoCombo);
        TextInputEditText etPrecioCombo = dialogView.findViewById(R.id.etPrecioCombo);
        ivCurrentDialogPhoto = dialogView.findViewById(R.id.ivComboFoto);
        Button btnSelectFoto = dialogView.findViewById(R.id.btnSelectFoto);

        if (isEdit) {
            tvDialogTitleCombo.setText("Editar Combo");
            Combo combo = comboList.get(position);
            etNombreCombo.setText(combo.getNombre());
            etContenidoCombo.setText(combo.getContenido());
            etPrecioCombo.setText(String.valueOf(combo.getPrecio()));
            if (combo.getFotoUri() != null && !combo.getFotoUri().isEmpty()) {
                currentDialogPhotoUri = combo.getFotoUri();
                ivCurrentDialogPhoto.setImageURI(Uri.parse(currentDialogPhotoUri));
            }
        } else {
            tvDialogTitleCombo.setText("Nuevo Combo");
        }

        btnSelectFoto.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            photoPickerLauncher.launch(intent);
        });

        new MaterialAlertDialogBuilder(this)
                .setView(dialogView)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String nombre = etNombreCombo.getText() != null
                            ? etNombreCombo.getText().toString().trim() : "";
                    String contenido = etContenidoCombo.getText() != null
                            ? etContenidoCombo.getText().toString().trim() : "";
                    String precioStr = etPrecioCombo.getText() != null
                            ? etPrecioCombo.getText().toString().trim() : "";

                    if (nombre.isEmpty()) {
                        Toast.makeText(this, "El nombre del combo es obligatorio", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (precioStr.isEmpty()) {
                        Toast.makeText(this, "El precio es obligatorio", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double precio;
                    try {
                        precio = Double.parseDouble(precioStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Ingrese un precio válido", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (isEdit) {
                        Combo combo = comboList.get(position);
                        boolean updated = dbHelper.actualizarCombo(combo.getId(), nombre, contenido, currentDialogPhotoUri, precio);
                        if (updated) {
                            combo.setNombre(nombre);
                            combo.setContenido(contenido);
                            combo.setFotoUri(currentDialogPhotoUri);
                            combo.setPrecio(precio);
                            adapter.notifyItemChanged(position);
                            Toast.makeText(this, "Combo actualizado", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Error al actualizar combo", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        long id = dbHelper.insertarCombo(empresaId, nombre, contenido, currentDialogPhotoUri, precio);
                        if (id != -1) {
                            comboList.add(new Combo(id, empresaId, nombre, contenido, currentDialogPhotoUri, precio));
                            adapter.notifyItemInserted(comboList.size() - 1);
                            rvCombos.smoothScrollToPosition(comboList.size() - 1);
                            Toast.makeText(this, "Combo agregado", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Error al agregar combo", Toast.LENGTH_SHORT).show();
                        }
                    }
                    updateEmptyState();
                })
                .show();
    }
}
