package com.example.chirieats;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class CarritoActivity extends AppCompatActivity implements CarritoAdapter.OnCartItemActionListener {

    private RecyclerView rvCarrito;
    private ImageButton btnBack;
    private ImageButton btnClearCart;
    private LinearLayout layoutEmptyCart;
    private TextView tvTotalCarrito;
    private MaterialButton btnPagar;
    private LinearLayout layoutCheckoutBar;

    private List<CartItem> cartItemList;
    private CarritoAdapter adapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);

        dbHelper = new DatabaseHelper(this);

        initViews();
        initData();
        setupRecyclerView();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatos();
    }

    private void initViews() {
        rvCarrito = findViewById(R.id.rvCarrito);
        btnBack = findViewById(R.id.btnBack);
        btnClearCart = findViewById(R.id.btnClearCart);
        layoutEmptyCart = findViewById(R.id.layoutEmptyCart);
        tvTotalCarrito = findViewById(R.id.tvTotalCarrito);
        btnPagar = findViewById(R.id.btnPagar);
        layoutCheckoutBar = findViewById(R.id.layoutCheckoutBar);
    }

    private void initData() {
        cartItemList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        adapter = new CarritoAdapter(cartItemList, this);
        rvCarrito.setLayoutManager(new LinearLayoutManager(this));
        rvCarrito.setAdapter(adapter);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());
        
        btnClearCart.setOnClickListener(v -> {
            dbHelper.vaciarCarrito();
            cargarDatos();
            Toast.makeText(this, "Carrito vaciado", Toast.LENGTH_SHORT).show();
        });

        btnPagar.setOnClickListener(v -> {
            if (cartItemList.isEmpty()) {
                Toast.makeText(this, "El carrito está vacío", Toast.LENGTH_SHORT).show();
                return;
            }
            double total = calcularTotal();
            Intent intent = new Intent(this, PagoClienteActivity.class);
            intent.putExtra("total_pago", total);
            startActivity(intent);
        });
    }

    private void cargarDatos() {
        cartItemList.clear();
        cartItemList.addAll(dbHelper.obtenerCarrito());
        adapter.notifyDataSetChanged();

        if (cartItemList.isEmpty()) {
            layoutEmptyCart.setVisibility(View.VISIBLE);
            rvCarrito.setVisibility(View.GONE);
            layoutCheckoutBar.setVisibility(View.GONE);
        } else {
            layoutEmptyCart.setVisibility(View.GONE);
            rvCarrito.setVisibility(View.VISIBLE);
            layoutCheckoutBar.setVisibility(View.VISIBLE);
        }

        actualizarTotal();
    }

    private void actualizarTotal() {
        double total = calcularTotal();
        tvTotalCarrito.setText(String.format("$%.2f", total));
    }

    private double calcularTotal() {
        double total = 0;
        for (CartItem item : cartItemList) {
            total += (item.getPrecio() * item.getCantidad());
        }
        return total;
    }

    @Override
    public void onRemoveItem(int position, CartItem item) {
        boolean deleted = dbHelper.eliminarItemCarrito(item.getId());
        if (deleted) {
            cartItemList.remove(position);
            adapter.notifyItemRemoved(position);
            adapter.notifyItemRangeChanged(position, cartItemList.size());
            cargarDatos(); // Refresh visibility and total
        } else {
            Toast.makeText(this, "Error al eliminar del carrito", Toast.LENGTH_SHORT).show();
        }
    }
}
