package com.example.chirieats;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MenuClienteAdapter extends RecyclerView.Adapter<MenuClienteAdapter.ViewHolder> {

    public interface OnComboClickListener {
        void onComboClick(Combo combo);
    }

    private final List<Combo> comboList;
    private final OnComboClickListener listener;

    public MenuClienteAdapter(List<Combo> comboList, OnComboClickListener listener) {
        this.comboList = comboList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_menu_cliente, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Combo combo = comboList.get(position);
        holder.tvNombre.setText(combo.getNombre());
        holder.tvContenido.setText(combo.getContenido() != null ? combo.getContenido() : "");
        holder.tvPrecio.setText(String.format("$%.2f", combo.getPrecio()));

        if (combo.getFotoUri() != null && !combo.getFotoUri().isEmpty()) {
            holder.ivFoto.setImageURI(Uri.parse(combo.getFotoUri()));
        } else {
            holder.ivFoto.setImageResource(R.drawable.ic_food);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onComboClick(combo);
            }
        });
    }

    @Override
    public int getItemCount() {
        return comboList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivFoto;
        final TextView tvNombre;
        final TextView tvContenido;
        final TextView tvPrecio;

        ViewHolder(View itemView) {
            super(itemView);
            ivFoto = itemView.findViewById(R.id.ivComboFoto);
            tvNombre = itemView.findViewById(R.id.tvNombreCombo);
            tvContenido = itemView.findViewById(R.id.tvContenidoCombo);
            tvPrecio = itemView.findViewById(R.id.tvPrecioCombo);
        }
    }
}
