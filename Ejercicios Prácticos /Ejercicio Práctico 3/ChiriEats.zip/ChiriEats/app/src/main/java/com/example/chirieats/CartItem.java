package com.example.chirieats;

/**
 * Modelo que representa un artículo en el carrito de compras.
 */
public class CartItem {

    private long id;
    private long comboId;
    private String nombreCombo;
    private double precio;
    private String fotoUri;
    private int cantidad;

    public CartItem(long id, long comboId, String nombreCombo, double precio, String fotoUri, int cantidad) {
        this.id = id;
        this.comboId = comboId;
        this.nombreCombo = nombreCombo;
        this.precio = precio;
        this.fotoUri = fotoUri;
        this.cantidad = cantidad;
    }

    public CartItem(long comboId, String nombreCombo, double precio, String fotoUri, int cantidad) {
        this(-1, comboId, nombreCombo, precio, fotoUri, cantidad);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getComboId() {
        return comboId;
    }

    public void setComboId(long comboId) {
        this.comboId = comboId;
    }

    public String getNombreCombo() {
        return nombreCombo;
    }

    public void setNombreCombo(String nombreCombo) {
        this.nombreCombo = nombreCombo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getFotoUri() {
        return fotoUri;
    }

    public void setFotoUri(String fotoUri) {
        this.fotoUri = fotoUri;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
