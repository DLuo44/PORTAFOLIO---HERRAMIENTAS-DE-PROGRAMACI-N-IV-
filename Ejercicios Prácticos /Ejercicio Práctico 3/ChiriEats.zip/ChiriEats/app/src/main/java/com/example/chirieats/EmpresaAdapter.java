package com.example.chirieats;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter para el RecyclerView de empresas.
 * Maneja la visualización de cada empresa y delega las acciones
 * de editar y eliminar a la Activity a través de la interfaz OnEmpresaActionListener.
 */
public class EmpresaAdapter extends RecyclerView.Adapter<EmpresaAdapter.EmpresaViewHolder> {

    /**
     * Interfaz de callback para manejar las acciones sobre cada empresa.
     */
    public interface OnEmpresaActionListener {
        void onEdit(int position);
        void onDelete(int position);
        void onItemClick(int position);
    }

    private final List<Empresa> empresaList;
    private final OnEmpresaActionListener listener;

    /**
     * Constructor del adapter.
     *
     * @param empresaList Lista de empresas a mostrar.
     * @param listener    Listener para las acciones de editar/eliminar.
     */
    public EmpresaAdapter(List<Empresa> empresaList, OnEmpresaActionListener listener) {
        this.empresaList = empresaList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public EmpresaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_empresa, parent, false);
        return new EmpresaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EmpresaViewHolder holder, int position) {
        Empresa empresa = empresaList.get(position);
        holder.tvNombre.setText(empresa.getNombre());
        holder.tvDescripcion.setText(empresa.getDescripcion());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getBindingAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    listener.onItemClick(adapterPosition);
                }
            }
        });

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getBindingAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    listener.onEdit(adapterPosition);
                }
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getBindingAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    listener.onDelete(adapterPosition);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return empresaList.size();
    }

    /**
     * ViewHolder que mantiene las referencias a las vistas de cada ítem.
     */
    static class EmpresaViewHolder extends RecyclerView.ViewHolder {

        final TextView tvNombre;
        final TextView tvDescripcion;
        final ImageButton btnEdit;
        final ImageButton btnDelete;

        EmpresaViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre     = itemView.findViewById(R.id.tvNombre);
            tvDescripcion = itemView.findViewById(R.id.tvDescripcion);
            btnEdit      = itemView.findViewById(R.id.btnEdit);
            btnDelete    = itemView.findViewById(R.id.btnDelete);
        }
    }
}
