package com.example.chirieats;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

/**
 * MainActivity — Menú Principal de Chiriquí Eats S.A.
 *
 * Presenta dos opciones de navegación:
 *   1. Ingresar como Empresa (Administración)
 *   2. Ingresar como Cliente (Compras)
 */
public class MainActivity extends AppCompatActivity {

    private MaterialCardView cardEmpresa;
    private MaterialCardView cardCliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupListeners();
    }

    private void initViews() {
        cardEmpresa = findViewById(R.id.cardEmpresa);
        cardCliente = findViewById(R.id.cardCliente);
    }

    private void setupListeners() {
        cardEmpresa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EmpresasAdminActivity.class);
                startActivity(intent);
            }
        });

        cardCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ClienteDashboardActivity.class);
                startActivity(intent);
            }
        });
    }
}
